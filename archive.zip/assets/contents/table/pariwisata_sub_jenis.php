<div class="card">
    <div class="card-body">
        <h4 class="card-title">Sub Jenis Pariwisata</h4>
        <h6 class="card-subtitle">Data table example</h6>
        <div class="table-responsive m-t-40">
            <table id="table_pariwisata_sub_jenis" class="display table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Jenis</th>
                        <th>Keterangan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
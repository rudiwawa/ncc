<div class="card">
    <div class="card-body">
        <h4 class="card-title">Jenis Pariwisata</h4>
        <h6 class="card-subtitle">Data table example</h6>
        <div class="table-responsive m-t-40">
            <table id="table_pariwisata_jenis" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Keterangan</th>
                        <th>Gambar</th>
                        <th>Is Delete</th>
                        <th>Time Update</th>
                        <th>Admin</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>